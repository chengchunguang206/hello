﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See LICENSE in the project root for license information.

using System;

namespace Microsoft.MixedReality.SpectatorView
{
    [Flags]
    internal enum TextMeshProBroadcasterChangeType : byte
    {
        None = 0x0,
        Text = 0x1,
        FontAndPlacement = 0x2
    }
}